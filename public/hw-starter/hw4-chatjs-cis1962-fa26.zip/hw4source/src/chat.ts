import { chatAPI } from "./chat-api.js";
import type { Message } from "./types.js";

// ** TODO **
// Generate your own Gemini API key and fill it in below.
// This is a hard-coded key, and generally not a good practice, but for this assignment, it is acceptable.
const GEMINI_API_KEY = "YOUR_GEMINI_API_KEY";
// This is the URL for the Gemini API, which is used to generate responses from the model.
// If you'd like to test other google models, you can change the model name in the URL below. 
//For example, you could use "gemini-3.5" or "gemini-3.5-turbo" instead of "gemini-3.8-flash". Some models may be unavailable through this method.
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${GEMINI_API_KEY}`;

/**
 * Generates a response from the Gemini API
 * This has been provided in the starter code, and should generally not be modified unless you know what you are doing.
 * @param {string[]} messages - The messages to generate a response for
 * @returns {string} - The response from the Gemini API
 */
const generateGeminiResponse = async (messages: Message[]): Promise<string | undefined> => {
    const response = await fetch(GEMINI_API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-goog-api-key": GEMINI_API_KEY
        },
        body: JSON.stringify({
            contents: messages.map(message => ({ role: message.role, parts: [{ text: message.content }] }))
        })
    });
    const data = await response.json();
    const content = data.candidates[0].content.parts[0].text;
    return content;
};

/**
 * The Chat class
 * @param {string} id - The id of the chat
 * @param {string[]} messages - The messages in the chat
 */
export class Chat {
    /**
     * The constructor for the Chat class
     * @requirements
     * - Should store the id and messages
     * @param {string} id - The id of the chat
     * @param {string[]} messages - The messages in the chat
     */
    id: string;
    messages: Message[];

    constructor({ id, messages }: { id: string; messages: Message[] }) {
        // ** TODO **
    }

    /**
     * Gets the messages in the chat
     * @usage const messages = chat.getMessages();
     * @returns {string[]} - The messages in the chat
     */
    getMessages(): Message[] {
        // ** TODO **
    }

    /**
     * Sends a message to the chat
     * @usage const messages = await chat.sendMessage("Hello, how are you?");
     * @param {string} message - The message to send
     * @returns {Promise<string[]>} - The messages in the chat, including the new messages
     */
    async sendMessage(message: string): Promise<Message[]> {
        // ** TODO **
    }

    /**
     * Saves the chat
     * @usage await chat.save();
     * @returns {Promise<void>} - The promise to save the chat
     */
    async save(): Promise<void> {
        // ** TODO **
    }
}