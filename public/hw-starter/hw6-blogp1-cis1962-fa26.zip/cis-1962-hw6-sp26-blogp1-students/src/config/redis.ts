import { createClient } from 'redis';
import dotenv from 'dotenv';

dotenv.config();

const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379'; // 2nd link is a local Redis instance if Cloud does not work

const client = createClient({
    url: redisUrl,
});

client.on('error', (err) => console.log('Redis Client Error', err));

await client.connect();
console.log('Redis connected successfully');

export default client;
