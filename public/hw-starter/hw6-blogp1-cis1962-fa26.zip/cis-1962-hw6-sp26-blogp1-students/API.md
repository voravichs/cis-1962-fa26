# API Documentation

## Auth Endpoints

### Method: POST /register
- **Description**: Create a new user account. Validates that user input meets the required criteria and that the username is unique within the database. Hashes the user inputted password before creating a user with the role user.
- **Request Body (JSON)**:
    - username: string (required, 3-20 alphanumeric chars, no spaces)
    - password: string (required, min 8 chars, at least one letter and one number)
    - email: string (required, valid email format, like example@domain.com)
- **Response**:
    - 201 Success: { message: 'Account created' }
    - 400 Error: { error: 'Missing fields: ...' } or validation error messages
    - 409 Error: { error: 'Username or email already exists.' }
- **Database Interaction**:
    - Creates a Redis hash under the key user:[username] that stores the following fields:
        - username: the user's username
        - email: the user's email address
        - passwordHash: the user's password hashed securely with bcrypt
        - role: defaults to user

### Method: POST /login
- **Description**: Log in to an existing user account. Validates that the username and password are provided, checks that the username exists in the database, and compares the provided password with the stored hashed password using bcrypt. If the credentials are valid, generates a JWT token that includes the user's username and role, and returns it in the response.
- **Request Body (JSON)**:
    - username: string (required)
    - password: string (required)
- **Response**:
    - 200 Success: { message: 'Login successful', jwt_token }
    - 400 Error: { error: 'Missing username or password' }
    - 401 Error: { error: 'Invalid credentials' }
- **Database Interaction**:
    - Get a user by username from database to compare login credentials

## Profile Endpoints

### Method: GET /profile
- **Description**: Fetch the profile information for the currently authenticated user.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Response**:
    - 200 Success: { username, email, role, description? }
    - 401 Error: { error: 'Unauthorized' }
    - 400 Error: { error: 'Missing username in token' }
    - 500 Error: { error: 'Failed to fetch profile' }
- **Database Interaction**:
    - Fetches the user's profile from Redis, excluding the password field for security.

### Method: PATCH /profile
- **Description**: Update the profile information for the currently authenticated user. Partially updates the user's profile fields depending on what is provided in the request body.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Body (JSON)**:
    - email: string (optional)
    - role: string (optional)
    - description: string (optional)
- **Response**:
    - 200 Success: { username, email, role, description? }
    - 401 Error: { error: 'Unauthorized' }
    - 400 Error: { error: 'Missing username in token' }
    - 500 Error: { error: 'Failed to update profile' }
- **Database Interaction**:
    - Updates the user's profile in Redis, excluding the password field for security.

## Blog Post Endpoints

### Method: POST /posts
- **Description**: Create a new blog post for the authenticated user. Each blog Post in the database should contain a unique ID created with @paralleldrive/cuid2, the username of the creator, a title, content, and a timestamp (Date) for when it was created.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Body (JSON)**:
    - title: string (required)
    - content: string (required)
- **Response**:
    - 201 Success: {post}: Post
    - 500 Error: { error: 'Failed to create post' }
- **Database Interaction**:
    - Stores the post object in the database with a unique ID, username, title, content, and timestamp.

### Method: GET /posts/:user
- **Description**: Get all blog posts for the specified user.
- **Authentication**: No authentication required.
- **Request Parameters**:
    - user: string (required, the username of the user)
- **Response**:
    - 200 Success: Array of Post objects
    - 500 Error: { error: 'Failed to fetch posts' }
- **Database Interaction**:
    - Fetches all posts for the specified user from the database.

### Method: GET /posts/:user/:id
- **Description**: Get a specific blog post by its ID for the specified user.
- **Authentication**: No authentication required.
- **Request Parameters**:
    - user: string (required, the username of the user)
    - id: string (required, the unique ID of the post)
- **Response**:
    - 200 Success: Post object
    - 404 Error: { error: 'Post not found' }
    - 500 Error: { error: 'Failed to fetch post' }
- **Database Interaction**:
    - Fetches a specific post by its ID for the specified user from the database.

### Method: PATCH /posts/:id
- **Description**: Update a specific blog post by its ID for the authenticated user. Partially updates the post fields depending on what is provided in the request body.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Parameters**:
    - id: string (required, the unique ID of the post)
- **Request Body (JSON)**:
    - title: string (optional)
    - content: string (optional)
- **Response**:
    - 200 Success: Updated post object
    - 404 Error: { error: 'Post not found' }
    - 500 Error: { error: 'Failed to update post' }
- **Database Interaction**:
    - Partially updates the specified post in the database with the provided fields.

### Method: DELETE /posts/:id
- **Description**: Delete a specific blog post by its ID for the authenticated user.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Parameters**:
    - id: string (required, the unique ID of the post)
- **Response**:
    - 200 Success: { message: 'Post deleted' }
    - 404 Error: { error: 'Post not found' }
    - 500 Error: { error: 'Failed to delete post' }
- **Database Interaction**:
    - Deletes the specified post from the database.

## Comment Endpoints

### Method: POST /posts/:id/comments
- **Description**: Create a new comment on the specified post. A Comment consists of a unique comment ID, the post ID it belongs to, the username of the commenter, the content of the comment, the post author, and a createdAt timestamp.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Parameters**:
    - id: string (required, the unique ID of the post)
- **Request Body (JSON)**:
    - content: string (required)
- **Response**:
    - 201 Success: {comment}: Comment
    - 500 Error: { error: 'Failed to create comment' }
- **Database Interaction**:
    - Stores the comment object in the database with a unique ID, post ID, username, content, post author, and timestamp.

### Method: GET /posts/:id/comments
- **Description**: Get all comments for the specified post. The response to this route should be paginated.
- **Authentication**: No authentication required.
- **Query Parameters**:
    - limit: number (optional, default: 5)
    - offset: number (optional, default: 0)
- **Request Parameters**:
    - id: string (required, the unique ID of the post)
- **Response**:
    - 200 Success: Array of Comment objects
    - 500 Error: { error: 'Failed to fetch comments' }
- **Database Interaction**:
    - Fetches comments for the specified post from the database with pagination support.

### Method: DELETE /posts/:id/comments/:commentId
- **Description**: Allows an authenticated user to delete a specific comment on their own post. User and post author must match for deletion to be successful.
- **Authentication**: JWT required in Authorization header. username must be present in the token.
- **Request Parameters**:
    - id: string (required, the unique ID of the post)
    - commentId: string (required, the unique ID of the comment)
- **Response**:
    - 200 Success: { message: 'Comment deleted' }
    - 404 Error: { error: 'Post/Comment not found or not authorized' }
    - 500 Error: { error: 'Failed to delete comment' }
- **Database Interaction**:
    - Deletes the specified comment from the post if the user is authorized.