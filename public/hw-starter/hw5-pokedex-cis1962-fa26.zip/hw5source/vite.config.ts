import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: "https://hw5-backend-fa26.onrender.com",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '/pokedex'),
      },
    },
  },
})
