# HW3: Portfolio Rubric

## HTML

- [ ] Portfolio contains pages for: 
  - [ ] A home page: This should be the main landing page of your portfolio.
  - [ ] An about page: This should provide information about you and your background.
  - [ ] A contact page: This should include a form for visitors to reach out to you.
  - [ ] A projects page: This should showcase your projects and work.
- [ ] Portfolio is a multi-page website, with each page accessible through some navigation menu
- [ ] HTML files are well-structured and use semantic HTML elements where appropriate

## CSS

- [ ] CSS makes use of at least one flexbox, if not more to properly layout elements
- [ ] CSS makes good use of colors, either built-in or though hex or RGB codes
- [ ] App makes good use of the box model with proper margins, padding, and borders where applicable
- [ ] CSS makes good use of at least 1 CSS variable, and uses it in at least 1 place
- [ ] CSS makes good use of at least 1 pseudo-class, and uses it in at least 1 place
- [ ] BONUS: CSS uses media queries to make the app responsive to 3 different screen sizes (mobile, tablet, desktop)

# Functionality

- [ ] Contact page has a form that allows users to submit their name, email, and message
- [ ] Form submission is validated on the client side, with appropriate error messages displayed for invalid input
- [ ] Portfolio includes one interactive feature implemented using JavaScript, such as a modal, carousel, or other interactive element
- [ ] Portfolio includes one dynamic feature implemented using JavaScript, such as displaying external data, updating UI based on the date, or other dynamic behavior

# Code & Polish

- [ ] Project scripts are written in TypeScript and compiled to JavaScript
- [ ] Scripts have no TypeScript errors, warnings, or bugs
- [ ] No 'any' types are parsed in TypeScript (unless a good reason is provided)
- [ ] Portfolio content is polished and professional. You should be proud to show this to a coworker or friend, or perhaps a future employer!

Note: We will only style check the .ts file!